import VerifyAccountForm from "@/components/form/verify-account-form";
import VerifyAccountLoader from "@/components/loader/verify-account-loader";
import Image from "next/image";

import Link from "next/link";
import { Suspense } from "react";

export default function VerifyAccountPage() {
  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      <div className="flex flex-col gap-4 p-6 md:p-10">
        <div className="flex justify-center gap-2 md:justify-start">
          <Link href="/" className="flex items-center gap-2 font-medium">
            <div className="flex items-center gap-2">
              <Image src="/logo.svg" alt="Power Guard logo" width="50" height="50" unoptimized loading="eager" />
              <p className="font-bold text-primary text-2xl">Power Guard</p>
            </div>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-xs">
            <Suspense fallback={<VerifyAccountLoader />}>
              <VerifyAccountForm mode="customer" />
            </Suspense>
          </div>
        </div>
      </div>
      <div className="relative hidden bg-muted lg:block">
        <Image
          src="/register.jpg"
          alt="Power Guard customer verification background"
          className="absolute inset-0 h-full w-full object-cover dark:brightness-[0.2] dark:grayscale" fill
          priority
          unoptimized
          sizes="50vw" loading="eager"
        />
      </div>
    </div>
  );
}
