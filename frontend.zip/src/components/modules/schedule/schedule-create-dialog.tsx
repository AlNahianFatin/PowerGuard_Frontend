import CreateScheduleForm from "@/components/form/create-schedule-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import type { Feeder } from "@/types";
import { PlusCircle } from "lucide-react";
import { useState } from "react";

export default function ScheduleCreateDialog({ feeders }: { feeders: Feeder[] }) {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={<Button size="lg" />}>
        <PlusCircle />
        <span>Create Schedule</span>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Schedule</DialogTitle>
          <DialogDescription>
            This schedule will be visible to everyone
          </DialogDescription>
        </DialogHeader>
        <CreateScheduleForm feeders={feeders} handleClose={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}
