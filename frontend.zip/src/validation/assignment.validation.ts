import z from "zod";

export enum ServiceRequestStatus {
    PENDING = "PENDING",
    ASSIGNED = "ASSIGNED",
    INSPECTING = "INSPECTING",
    PAYMENTPENDING = "PAYMENTPENDING",
    INPROGRESS = "INPROGRESS",
    RESOLVED = "RESOLVED",
    FAILED = "FAILED",
    REJECTED = "REJECTED",
    CANCELLED = "CANCELLED",
}

export const AssignTechnicianSchema = z.object({
    technicianId: z
        .string("Must include the technician ID")
        .min(1, "Must select a technician to assign to the service request"),

    notes: z
        .string("Must include a valid note for the technician or customer")
        .max(255, "Note must be within 255 characters")
        .optional(),
});

export const UpdateAssignmentSchema = z.object({
    technicianId: z
        .string("Must include the technician ID")
        .optional(),

    notes: z
        .string("Must include a valid note for the technician or customer")
        .max(255, "Note must be within 255 characters")
        .optional(),
});

export const UpdateAssignmentStatusSchema = z
    .object({
        status: z.enum(
            [
                "",
                ServiceRequestStatus.INSPECTING,
                ServiceRequestStatus.RESOLVED,
                ServiceRequestStatus.FAILED,
            ],
            "Please enter a valid status!",
        ),

        failureNote: z
            .string("Must include a valid failure note for the customer")
            .max(255, "Note must be within 255 characters")
            .optional(),
    })
    .superRefine((data, ctx) => {
        if (!data.status) {
            ctx.addIssue({
                code: "custom",
                path: ["status"],
                message: "Please select a status",
            });
        }

        if (
            data.status === ServiceRequestStatus.FAILED &&
            !data.failureNote?.trim()
        ) {
            ctx.addIssue({
                code: "custom",
                path: ["failureNote"],
                message: "Must include a valid failure note",
            });
        }
    });