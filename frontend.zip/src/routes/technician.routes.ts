const prefix = "/technician";

export const technicianRoutes = [
  {
    title: "Service",
    items: [
      {
        title: "Overview",
        url: `${prefix}`,
      },
      // {
      //   title: "Create Schedule",
      //   url: `${prefix}/schedules`,
      // },
      {
        title: "My Assignments",
        url: `${prefix}/my-assignments`,
      },
    ],
  },
  {
    title: "Account Settings",
    items: [
      {
        title: "Change Password",
        url: `${prefix}/change-password`,
      },
      {
        title: "Data Fetching",
        url: "#",
        isActive: true,
      },
    ],
  },
];
